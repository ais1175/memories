const socketio = require('socket.io');
const Sentry = require('@sentry/node');

const production = require('./config').PRODUCTION;

module.exports = function (server, game) {
	const io = socketio(server);

	game.on('game_starting', function (data) {
		io.emit('game_starting', data);
	});

	game.on('roll_1', function (data) {
		io.emit('roll_1', data);
	});

	game.on('roll_2', function (data) {
		io.emit('roll_2', data);
	});

	game.on('roll_3', function (data) {
		io.emit('roll_1', data);
	});

	game.on('roll_4', function (data) {
		io.emit('roll_4', data);
	});

	game.on('game_ended', function () {
		io.emit('game_ended');
	});

	io.on('connection', function (socket) {
		socket.on('place_bet', function (wager, balanceType, multiplier, callback) {
			// TODO: Add client validation
			if (multiplier !== 2 && multiplier !== 3 && multiplier !== 5 && multiplier !== 25) return callback('INVALID_MULTIPLIER');

			game.placeBet(wager, balanceType, multiplier, function (err) {
				if (err) {
					console.error(err);
					if (production) Sentry.captureException(err);
					return callback("INTERNAL_ERROR");
				}

				callback(null);
			})
		})
	});
}