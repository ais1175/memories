const http = require('http');
const sentry = require('@sentry/node');

const database = require('./database');
const Game = require('./game');
const socket = require('./socket');
const config = require('./config');

// Initialize Sentry
if (config.PRODUCTION) sentry.init({dsn: config.SENTRY_DSN});

// Create http server
const server = http.createServer();

// Start listening on server
server.listen(config.PORT, function () {
	console.log("Started horse racing game server on port " + config.PORT);
});

database.getLastGameId(function (err, id) {
	if (err) throw err;

	// Initialize game server
	const game = new Game(id);

	// Initialize socket.io
	socket(server, game);
});