/**
 * Generate a random number in between it's min and max values
 *
 * TODO: Use crypto library to generate cryptographically strong random number
 *
 * @param min The minimum value to generate in between
 * @param max The maximum value to generate in between
 * @returns {number} Random number
 */
function generateRandomBetween(min, max) {
	return Math.floor(Math.random() * (max - min + 1) + min);
}

/**
 * Generate a horses final position and its stages for it to
 * end in that position
 *
 * @param existingMaxes
 * @returns {{max: *, stages: [number, number, number, number]}}
 */
exports.generateStages = function (existingMaxes) {
	var max;

	/**
	 * Generate the final position of the horse
	 * @returns {{max: *, stages: [number, number, number, number]}|*}
	 */
	function generateMax() {
		max = generateRandomBetween(65, 100);
		if (existingMaxes.includes(max)) return generateMax();

		return generateRandoms();
	}

	/**
	 * Generate the stages for the horse so it ends at its final (max)
	 * position
	 *
	 * @returns {{max: *, stages: [number, number, number, number]}}
	 */
	function generateRandoms() {
		const random1 = generateRandomBetween(max - 3);
		const random2 = generateRandomBetween(max - 2 - random1);
		const random3 = generateRandomBetween(max - 1 - random1 - random2);
		const random4 = 100 - random1 - random2 - random3;

		return {"max": max, "stages": [random1, random2, random3, random4]};
	}

	return generateMax();
}