const mongoose = require('mongoose');

const Game = require('./models/GameSchema');
const Result = require('./models/ResultSchema');
const Balance = require('./models/BalanceSchema');

const lib = require('./lib');
const config = require('./config');

mongoose.connect(config.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

exports.getLastGameId = function (callback) {
	Game.find({}).sort({ gameId: -1 }).limit(1).exec(function (err, game) {
		if (err) return callback(err);

		if (!game.gameId) game.gameId = 1;

		callback(null, game.gameId);
	})
}

exports.createGame = function (gameId, callback) {
	let endings = [];
	let existing_maxes = [];

	// Generate stages for each of the 4 horses
	for (let i = 0; i <= 3; i++) {
		let stage = lib.generateStages(existing_maxes);

		existing_maxes.push(stage.max);
		endings.push(stage.stages);
	}

	const game = new Game({
		gameId: gameId,
		stages: endings,
		startedAt: new Date()
	});

	game.save(function (err) {
		if (err) return callback(err);

		callback(null, endings);
	})
}

exports.finishGame = function (gameId, callback) {
	Game.findOneAndUpdate({ gameId: gameId }, { endedAt: new Date() }, function (err) {
		if (err) return callback(err);

		callback(null);
	})
}

exports.placeBet = function (userId, wager, balanceType, multiplier, callback) {
	const bet = new Result({
		user: userId,
		wager: wager,
		balanceType: balanceType,
		multiplier: multiplier,
		game: 'horse',
	})

	// TODO: Use transactions
	Balance.findOneAndUpdate({ user_id: userId, type: balanceType }, { $inc: { amount: wager * -1 }}, function (err) {
		if (err) return callback(err);

		bet.save(function (err, data) {
			if (err) return callback(err);

			// TODO: Check if this is data._id or data.id
			callback(null, data.id);
		})
	})
}

exports.updatePlayerWinnings = function (userId, balanceType, betId, wager, multiplier, callback) {
	Result.findOneAndUpdate({ _id: betId }, { multiplier: multiplier, status: 'win', profit: (wager * multiplier) - wager}, function (err) {
		if (err) return callback(err);

		Balance.findOneAndUpdate({ user_id: userId, type: balanceType }, { $inc: { amount: wager * multiplier }}, function (err) {
			if (err) return callback(err);

			callback(null);
		})
	})
}

exports.updateLossResults = function (betId, callback) {
	Result.findOneAndUpdate({ _id: betId }, { status: 'loss', profit: 0 }, function (err) {
		if (err) return callback(err);
	})
}