require('dotenv').config();

module.exports = {
	"PRODUCTION": process.env.NODE_ENV === "production",
	"PORT": 3000,
	"SENTRY_DSN": process.env.SENTRY_DSN,
	"MONGO_URI": process.env.MONGO_URI,
	"START_TIME": 5000,
	"DELAY_TIME": 1500
}