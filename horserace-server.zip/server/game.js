const Sentry = require('@sentry/node');
const events = require('events');

const database = require('./database');
const config = require('./config');
const util = require('util');

// TODO: Move these settings to database
const startTime = config.START_TIME; // Time between announcing game is starting and game starting
const delayTime = config.DELAY_TIME; // Time between rolls where horses can move

const production = config.PRODUCTION;

function Game(lastGameId) {
	var self = this;

	self.state = "ENDED";
	self.id = lastGameId;
	self.players = [];

	createGame();
	function createGame() {
		// Set game ID
		let newId = self.id + 1;
		
		// Create incomplete game in database
		database.createGame(newId, function (err, endings) {
			if (err) {
				console.error("Unable to create game id " + newId);
				return setTimeout(createGame, 1500);
			}
			
			// Set game properties
			self.id = newId;
			self.state = "STARTING";
			self.stages = endings;
			self.players = []; // Reset players in game
			// Stages: [{"id": "roll_1", "horses": [{"horse_1": ]]

			self.emit('game_starting', {
				id: newId,
				startTime: startTime,
				delayTime: delayTime
			})

			setTimeout(startGame, startTime);
		})
	}

	function startGame() {
		self.state = "STARTED";

		// Send first roll stage
		self.emit('roll_1', {
			players: self.stages[0]
		})

		setTimeout(roll_2, delayTime);

		function roll_2() {
			self.emit('roll_2', {
				horses: self.stages[1]
			});

			setTimeout(roll_3, delayTime);
		}

		function roll_3() {
			self.emit('roll_3', {
				horses: self.stages[2]
			});

			setTimeout(roll_4, delayTime);
		}

		function roll_4() {
			self.emit('roll_4', {
				horses: self.stages[3]
			});

			calculate_winner();
		}

		function calculate_winner() {
			self.emit('game_ended');
			self.state = "ENDED";

			const winner_horse_index = self.stages[3].indexOf(Math.max.apply(Math, self.stages[3]));
			const multipliers = [2, 3, 5, 25];

			const winner_multiplier = multipliers[winner_horse_index]

			// For all players that bet on this round, add their money * multiplier back to their account
			self.players.forEach(result => {
				if (result.multiplier === winner_multiplier) {
					database.updatePlayerWinnings(result.userId, result.balanceType, result.betId, result.wager, result.multiplier, function (err) {
						// TODO: Make error handling better here (possibly let client know that their money was unable to be processed)
						if (err) {
							if (production) Sentry.captureException(err);
							console.error(err);
						}
					})
				} else [
					database.updateLossResults(result.betId, function (err) {
						if (err) {
							if (production) Sentry.captureException(err);
							console.error(err);
						}
					})
				]
			});

			setTimeout(startGame, delayTime);
		}
	}
}

Game.prototype.placeBet = function (wager, balanceType, multiplier, callback) {
	var self = this;

	// TODO: Fetch user details from database SECURELY
	var user = {};

	// All game specific errors are handled here
	if (self.state !== "STARTING") return callback('GAME_ALREADY_STARTED');

	// Make sure player hasn't already bet
	for (let i = 0; i <= self.players - 1; i++) {
		if (self.players[i].userId === user.id) return callback('BET_ALREADY_PLACED');
	}

	database.placeBet(wager, balanceType, multiplier, function (err, id) {
		if (err) return callback(err);

		self.players.push({ userId: user.userId, balanceType: balanceType, betId: id, wager: wager, multiplier: multiplier });

		self.emit('new_bet', {
			username: user.name,
			multiplier: multiplier
		});

		callback(null);
	})
}

util.inherits(Game, events.EventEmitter);

module.exports = Game;