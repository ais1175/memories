const mongoose = require('mongoose');
const Schema = mongoose.Schema;

module.exports = mongoose.model('horse_games', new Schema({
	gameId: Number,
	stages: Array,
	startedAt: Date,
	endedAt: Date
}));