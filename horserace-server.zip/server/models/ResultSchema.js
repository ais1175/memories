const mongoose = require('mongoose');
const Schema = mongoose.Schema;

module.exports = mongoose.model('horse_results', new Schema({
	user: String,
	game: String,
	wager: Number,
	multiplier: Number,
	status: String,
	profit: Number,
	balanceType: String
}));