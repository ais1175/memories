const mongoose = require('mongoose');
const Schema = mongoose.Schema;

module.exports = mongoose.model('balance', new Schema({
	user_id: String,
	type: String,
	amount: Number,
	played_amount: Number
}));